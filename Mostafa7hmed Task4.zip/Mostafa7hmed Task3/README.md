# ✔️ Flutter Social Media Integeration

A Flutter app based on the design of the Social Media Integeration App, created by *Achmad Rizki Nur Fauzie*,

## Features
- Login with google
- Login with Facebook
- After Login, show details ( profile picture, name, email )
- Clean Code
- Clean UI
## Getting Started 🚀

```shell
- Clone the repo
- Install the dependicies
- Run it
```

## Preview App
![iphone-mockup-scene@2x](https://user-images.githubusercontent.com/75843138/133869389-52e01af0-5571-424c-b9c8-4fee0c053f85.png)

<img src="https://user-images.githubusercontent.com/75843138/133869227-797451f1-f8d5-4d73-bcfb-ea3c43e8be08.jpg" alt="alt text" width="300" height="600"> <img src="https://user-images.githubusercontent.com/75843138/133869231-2ea19d22-ccef-498f-b9f6-e1bc3fc10d8b.jpg" alt="alt text" width="300" height="600">

## Video Preview (No Ads !)
https://user-images.githubusercontent.com/75843138/133888074-73ca497b-d5e0-41b1-b079-e1c6cf935494.mp4

